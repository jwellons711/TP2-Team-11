﻿Public Class ObjectCreator
    'Team 11: creates the objects and lists for the Cars table
    Public Sub CreateObjectsAndLists()
        'Team 11: this is the connection string
        Dim myConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\ASET\Desktop\ProjectDatabase.mdb"
        Dim mySQL As String 'Team 11: creates a string object for mySQL
        Dim tablename As String 'Team 11: creates a String object called tableName
        Dim myDataSet As New DataSet 'Team 11: creates a new DataSet called myDataSet
        Dim myDBMS As New DBMS 'Team 11: creates a new DBMS object called myDBMS
        'Team 11: This loop transfers data out of the database and puts it into the Cars Table
        tablename = "Cars"
        mySQL = "SELECT * FROM " & tablename
        myDBMS.RunSQL(tablename, mySQL, myDataSet, myConnectionString)

        For rowNumber As Integer = 0 To myDataSet.Tables(tablename).Rows.Count - 1
            Dim myCar As New Cars
            myCar.ID = myDataSet.Tables(tablename).Rows(rowNumber)("ID")
            myCar.CarName = myDataSet.Tables(tablename).Rows(rowNumber)("Location")
            myCar.Cost = myDataSet.Tables(tablename).Rows(rowNumber)("Cost")
            myCar.MPG = myDataSet.Tables(tablename).Rows(rowNumber)("MPG")
            myCar.Comfort = myDataSet.Tables(tablename).Rows(rowNumber)("Comfort")
            myCar.Utility = myDataSet.Tables(tablename).Rows(rowNumber)("Utility")
            myCar.Interior = myDataSet.Tables(tablename).Rows(rowNumber)("Interior")

            Cars.CarsList.Add(myCar)
        Next
    End Sub


End Class
